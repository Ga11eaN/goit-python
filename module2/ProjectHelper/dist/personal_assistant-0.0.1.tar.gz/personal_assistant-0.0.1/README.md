This is the helper with the functions:
1. Create and work with Contacts lists.
2. Create and work with the notes.
3. Sorting files in the folders.

You can choose your options in the console.
Thank you for using our Helper.